<html>
<body>
<h1>Motel Jephen - Login</h1>
<form action="setpass.php" method=post>
MySQL username: <input type=text name="username" size=8>
MySQL password: <input type=password name="password" size=20>
<input type=submit value="Login">
</form>
</html>
