<?php

setcookie("username",'',1);
setcookie("password",'',1);

header('Location:index.php');

?>